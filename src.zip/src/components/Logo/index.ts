export { default } from './IretiLogo';
