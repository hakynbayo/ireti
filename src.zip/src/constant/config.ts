export const siteConfig = {
  title: 'Ireti Foundation',
  description:
    'Providing essential support for those in need.',
  /** Without additional '/' on the end, e.g. https://theodorusclarence.com */
  url: 'https://iretifoundation.com',
};
