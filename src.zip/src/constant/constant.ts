export const PRODUCT = 'product';
export const NAME = 'name';
export const COMPANY = 'company';
export const WORK_EMAIL = 'work_email';
export const EMAIL = 'email';
