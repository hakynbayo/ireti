export const navbarItems = [
  {
    link: 'About',
    text: 'About',
  },
  {
    link: 'Programs',
    text: 'Programs',
  },
  {
    link: 'Team',
    text: 'Team',
  },
  {
    link: 'Volunteer',
    text: 'Volunteer',
  },
];


