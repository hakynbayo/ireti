declare module 'react-modal';
